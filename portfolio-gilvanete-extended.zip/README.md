
# Portfólio - Gilvanete Simplicio da Silva

Portfólio profissional focado em **educação**, **tecnologia educacional** e **trabalho remoto**, com ênfase na transição estratégica para **desenvolvimento front-end**.

## Estrutura

- `index.html` – Versão principal em português.
- `index-en.html` – Versão em inglês do portfólio.
- `projects-tech.html` – Página destacando o portfólio tecnológico (componentes, layouts e integrações).
- `styles.css` – Estilos globais e responsivos.

## Como visualizar

Basta abrir o arquivo `index.html` em um navegador.

## Publicação no GitHub Pages

1. Crie um repositório no GitHub, por exemplo: `portfolio-gilvanete`.
2. Envie estes arquivos para o repositório.
3. Nas configurações do repositório, ative o **GitHub Pages** apontando para a branch `main`.
4. O portfólio ficará disponível em uma URL como:

   ```text
   https://seu-usuario.github.io/portfolio-gilvanete/
   ```

## Links importantes

- GitHub: [github.com/Giljared](https://github.com/Giljared)
- LinkedIn: [linkedin.com/in/gilvanete-silva](https://www.linkedin.com/in/gilvanete-silva/)
- Currículo Lattes: <http://lattes.cnpq.br/7090859930982601>
